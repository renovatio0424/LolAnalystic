package com.sample.renovatio.lolanalystic.View

import org.junit.Before
import org.junit.Test

import org.junit.Assert.*
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class MainActivityTest {

    @Before
    fun setUp() {
    }

    @Test
    fun getLayoutResourceId() {
    }

    @Test
    fun getViewModel() {
    }

    @Test
    fun initStartView() {
    }

    @Test
    fun initDataBinding() {
    }

    @Test
    fun initAfterBinding() {
    }
}
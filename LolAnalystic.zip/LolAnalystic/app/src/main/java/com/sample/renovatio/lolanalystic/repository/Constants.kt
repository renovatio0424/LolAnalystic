package com.sample.renovatio.lolanalystic.repository

object Constants {


}
package com.sample.renovatio.lolanalystic.ui.main

import android.arch.lifecycle.ViewModel

class MainViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}

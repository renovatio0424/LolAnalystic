package com.sample.renovatio.lolanalystic.repository

import android.arch.lifecycle.MutableLiveData
import android.arch.lifecycle.LiveData
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class ProjectRepository {
    private var gitHubService =  GitHubService

    fun getProjectList(userId: String): LiveData<List<Project>> {
        val data = MutableLiveData<List<Project>>()

        gitHubService.

        return data
    }
}
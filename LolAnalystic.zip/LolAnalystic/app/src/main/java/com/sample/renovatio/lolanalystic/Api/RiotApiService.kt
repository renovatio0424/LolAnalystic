package com.sample.renovatio.lolanalystic.Api

import com.sample.renovatio.lolanalystic.Model.Summoner
import io.reactivex.Single
import retrofit2.http.GET
import retrofit2.http.Path

interface RiotApiService {
    companion object {
        const val RIOT_API_KEY = "RGAPI-69b279f3-f0dc-4a59-893a-f2ef0dcecf4c"
    }

    @GET("/lol/summoner/v4/summoners/by-name/{summonerName}?api_key=$RIOT_API_KEY")
    fun searchSummonerByName(
        @Path("summonerName") name: String
    ): Single<Summoner>


}